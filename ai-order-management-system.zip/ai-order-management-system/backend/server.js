/**
 * LensFlow Backend API
 * ---------------------
 * A small Express server that powers the LensFlow order management
 * frontend. All data lives in memory (resets on server restart) —
 * swap the `db` object below for a real database (Postgres/Mongo) in production.
 *
 * Endpoints:
 *   GET    /api/inventory                 -> list in-house inventory rows
 *   POST   /api/check-availability        -> { lensType, sphere, index, coating } -> match result
 *   GET    /api/orders                    -> list orders (supports ?status, ?lensType, ?store, ?search)
 *   POST   /api/orders                    -> create a new order
 *   PATCH  /api/orders/:id                -> update status / delayReason
 *   GET    /api/kpis                      -> dashboard summary counts
 *   GET    /api/alerts                    -> TAT breach / at-risk predictions
 */

const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

// ---------------------------------------------------------------------
// CONSTANTS / "LEARNED FROM HISTORICAL DATA"
// ---------------------------------------------------------------------

const LENS_SLA_HOURS = {
  "Zero Power": 24,
  "Single Vision": 48,
  "Bifocal": 96,
  "Progressive": 120,
};

// Average hours spent per stage, by lens type (derived from historical run-rate)
const STAGE_AVG_HOURS = {
  "Zero Power":    { "Order Placed": 1, "Power Check": 1, "Lab Processing": 4,  "Coating": 3,  "QC": 2,  "Dispatch": 4 },
  "Single Vision": { "Order Placed": 2, "Power Check": 2, "Lab Processing": 18, "Coating": 8,  "QC": 4,  "Dispatch": 8 },
  "Bifocal":       { "Order Placed": 2, "Power Check": 3, "Lab Processing": 36, "Coating": 14, "QC": 8,  "Dispatch": 10 },
  "Progressive":   { "Order Placed": 2, "Power Check": 4, "Lab Processing": 48, "Coating": 18, "QC": 10, "Dispatch": 12 },
};

const STAGES = ["Order Placed", "Power Check", "Lab Processing", "Coating", "QC", "Dispatch", "Delivered"];

// In-house inventory, built from rolling 90-day dispatch history
const INVENTORY = [
  { lensType: "Single Vision", powerRange: [-6, 4],  index: "1.56", coating: "Anti-Reflective", stock: "In Stock" },
  { lensType: "Single Vision", powerRange: [-6, 4],  index: "1.56", coating: "Blue Cut",         stock: "In Stock" },
  { lensType: "Single Vision", powerRange: [-4, 2],  index: "1.59", coating: "Anti-Reflective", stock: "Low Stock" },
  { lensType: "Single Vision", powerRange: [-8, -6], index: "1.67", coating: "Anti-Reflective", stock: "Made-to-Order" },
  { lensType: "Bifocal",       powerRange: [-4, 4],  index: "1.56", coating: "Anti-Reflective", stock: "In Stock" },
  { lensType: "Bifocal",       powerRange: [-4, 4],  index: "1.59", coating: "Blue Cut",         stock: "Low Stock" },
  { lensType: "Progressive",   powerRange: [-4, 2],  index: "1.59", coating: "Blue Cut",         stock: "Low Stock" },
  { lensType: "Progressive",   powerRange: [-4, 2],  index: "1.67", coating: "Photochromic",     stock: "Made-to-Order" },
  { lensType: "Zero Power",    powerRange: [0, 0],   index: "1.56", coating: "UC (Uncoated)",    stock: "In Stock" },
  { lensType: "Zero Power",    powerRange: [0, 0],   index: "1.56", coating: "Blue Cut",         stock: "In Stock" },
];

// ---------------------------------------------------------------------
// IN-MEMORY "DATABASE"
// ---------------------------------------------------------------------

let orderSeq = 1042;
const db = { orders: [] };

function hoursAgo(h) {
  return new Date(Date.now() - h * 3600 * 1000);
}

function createOrder(opts) {
  orderSeq += 1;
  const lensType = opts.lensType;
  const slaHours = LENS_SLA_HOURS[lensType];
  const createdAt = opts.createdAt || new Date();
  const deadline = new Date(createdAt.getTime() + slaHours * 3600 * 1000);
  const order = {
    id: "LF-" + orderSeq,
    customer: opts.customer,
    store: opts.store,
    source: opts.source,
    lensType,
    sphere: opts.sphere ?? null,
    cyl: opts.cyl ?? null,
    index: opts.index ?? null,
    coating: opts.coating ?? null,
    frame: opts.frame ?? null,
    status: opts.status || "Order Placed",
    delayReason: opts.delayReason || "",
    createdAt,
    deadline,
    slaHours,
  };
  db.orders.push(order);
  return order;
}

// Seed demo data so the dashboard isn't empty on first load
function seed() {
  createOrder({ customer: "Rohan Mehta", store: "Bengaluru — Indiranagar", lensType: "Single Vision", status: "Lab Processing", createdAt: hoursAgo(40), source: "Store Walk-in" });
  createOrder({ customer: "Priya Nair",  store: "Mumbai — Bandra",         lensType: "Progressive",   status: "Lab Processing", createdAt: hoursAgo(100), source: "Website" });
  createOrder({ customer: "Sameer Khan", store: "Hubballi — Central",      lensType: "Bifocal",       status: "Coating",        createdAt: hoursAgo(70), source: "App" });
  createOrder({ customer: "Divya Iyer",  store: "Delhi — CP",              lensType: "Single Vision", status: "QC",             createdAt: hoursAgo(44), source: "Marketplace" });
  createOrder({ customer: "Kabir Singh", store: "Bengaluru — Indiranagar", lensType: "Progressive",   status: "QC",             createdAt: hoursAgo(118), source: "Store Walk-in", delayReason: "Re-loop: surfacing defect on first QC" });
  createOrder({ customer: "Meera Joshi", store: "Hubballi — Central",      lensType: "Zero Power",    status: "Dispatch",       createdAt: hoursAgo(20), source: "Website" });
  createOrder({ customer: "Arjun Verma", store: "Mumbai — Bandra",         lensType: "Single Vision", status: "Delivered",      createdAt: hoursAgo(60), source: "App" });
  createOrder({ customer: "Nisha Pillai",store: "Delhi — CP",              lensType: "Bifocal",       status: "Power Check",    createdAt: hoursAgo(6), source: "Store Walk-in" });
  createOrder({ customer: "Vivek Rao",   store: "Bengaluru — Indiranagar", lensType: "Progressive",   status: "Lab Processing", createdAt: hoursAgo(10), source: "Website" });
}
seed();

// ---------------------------------------------------------------------
// HELPERS
// ---------------------------------------------------------------------

function hoursLeft(order) {
  return (new Date(order.deadline).getTime() - Date.now()) / 3600000;
}

function slaState(order) {
  if (order.status === "Delivered") return "ok";
  const hl = hoursLeft(order);
  if (hl < 0) return "breach";
  const total = LENS_SLA_HOURS[order.lensType];
  if (hl < total * 0.25) return "risk";
  return "ok";
}

// TAT prediction model (lightweight heuristic standing in for the
// trained regression model described in the architecture note)
function predictRisk(order) {
  if (order.status === "Delivered") return null;
  const elapsedHours = (Date.now() - new Date(order.createdAt).getTime()) / 3600000;
  const currentIdx = STAGES.indexOf(order.status);
  const stagesFromCurrent = STAGES.slice(currentIdx, STAGES.length - 1); // exclude "Delivered"
  const remainingAvg = stagesFromCurrent.reduce(
    (sum, s) => sum + (STAGE_AVG_HOURS[order.lensType][s] || 0),
    0
  );
  const predictedTotal = elapsedHours + remainingAvg * 0.6;
  const slaHours = LENS_SLA_HOURS[order.lensType];

  if (predictedTotal > slaHours) return { level: "breach", predictedTotal, slaHours };
  if (predictedTotal > slaHours * 0.8) return { level: "risk", predictedTotal, slaHours };
  return null;
}

function checkAvailability(lensType, sphere, index, coating) {
  return INVENTORY.find(
    (r) =>
      r.lensType === lensType &&
      sphere >= r.powerRange[0] &&
      sphere <= r.powerRange[1] &&
      r.index === index &&
      r.coating === coating
  );
}

function serializeOrder(o) {
  return {
    ...o,
    createdAt: o.createdAt.toISOString(),
    deadline: o.deadline.toISOString(),
    hoursLeft: hoursLeft(o),
    slaState: slaState(o),
  };
}

// ---------------------------------------------------------------------
// ROUTES
// ---------------------------------------------------------------------

// Reference data the frontend needs to build its forms / legends
app.get("/api/meta", (req, res) => {
  res.json({
    lensSlaHours: LENS_SLA_HOURS,
    stages: STAGES,
    stores: [...new Set(db.orders.map((o) => o.store))].concat([
      "Bengaluru — Indiranagar",
      "Hubballi — Central",
      "Mumbai — Bandra",
      "Delhi — CP",
    ]).filter((v, i, a) => a.indexOf(v) === i),
  });
});

// Module 1: Inventory
app.get("/api/inventory", (req, res) => {
  res.json(INVENTORY);
});

app.post("/api/check-availability", (req, res) => {
  const { lensType, sphere, index, coating } = req.body;
  if (!lensType || sphere === undefined || !index || !coating) {
    return res.status(400).json({ error: "lensType, sphere, index and coating are required" });
  }
  const match = checkAvailability(lensType, Number(sphere), index, coating);
  const slaHours = LENS_SLA_HOURS[lensType];
  const s = STAGE_AVG_HOURS[lensType];

  let etaHours, statusLabel, level;
  if (match && match.stock === "In Stock") {
    etaHours = Math.min(8, s["Dispatch"]);
    statusLabel = "In-House Stock — Ships ASAP";
    level = "in-stock";
  } else if (match && match.stock === "Low Stock") {
    etaHours = s["Lab Processing"] * 0.4 + s["Coating"] + s["QC"] + s["Dispatch"];
    statusLabel = "Partial Stock — Topping Up + Coating";
    level = "low-stock";
  } else {
    etaHours = s["Power Check"] + s["Lab Processing"] + s["Coating"] + s["QC"] + s["Dispatch"];
    statusLabel = "Made-to-Order — Full Lab Cycle";
    level = "made-to-order";
  }

  res.json({
    match: match || null,
    level,
    statusLabel,
    slaHours,
    etaHours,
    eta: new Date(Date.now() + etaHours * 3600 * 1000).toISOString(),
  });
});

// Module 2: Orders / Dashboard
app.get("/api/orders", (req, res) => {
  const { status, lensType, store, search } = req.query;
  let list = db.orders;
  if (status) list = list.filter((o) => o.status === status);
  if (lensType) list = list.filter((o) => o.lensType === lensType);
  if (store) list = list.filter((o) => o.store === store);
  if (search) {
    const q = String(search).toLowerCase();
    list = list.filter(
      (o) => o.id.toLowerCase().includes(q) || o.customer.toLowerCase().includes(q)
    );
  }
  // newest first
  list = [...list].sort((a, b) => b.createdAt - a.createdAt);
  res.json(list.map(serializeOrder));
});

app.post("/api/orders", (req, res) => {
  const { customer, source, store, lensType, sphere, cyl, index, coating, frame } = req.body;
  if (!customer || !store || !lensType || !index || !coating) {
    return res.status(400).json({ error: "Missing required order fields" });
  }
  const order = createOrder({
    customer, source, store, lensType,
    sphere: sphere !== undefined ? Number(sphere) : null,
    cyl: cyl !== undefined ? Number(cyl) : null,
    index, coating, frame,
    status: "Order Placed",
  });
  res.status(201).json(serializeOrder(order));
});

app.patch("/api/orders/:id", (req, res) => {
  const order = db.orders.find((o) => o.id === req.params.id);
  if (!order) return res.status(404).json({ error: "Order not found" });

  const { status, delayReason } = req.body;

  if (status && status !== order.status) {
    // QC fail loop-back: log automatically
    if (order.status === "QC" && status === "Lab Processing") {
      order.delayReason = (order.delayReason ? order.delayReason + " | " : "") + "QC fail — looped back to Lab Processing";
    }
    order.status = status;
  }
  if (delayReason !== undefined) {
    order.delayReason = delayReason;
  }
  res.json(serializeOrder(order));
});

// KPIs for dashboard cards
app.get("/api/kpis", (req, res) => {
  const active = db.orders.filter((o) => o.status !== "Delivered");
  const breached = active.filter((o) => slaState(o) === "breach").length;
  const atRisk = active.filter((o) => slaState(o) === "risk").length;
  res.json({
    active: active.length,
    onTrack: active.length - breached - atRisk,
    atRisk,
    breached,
  });
});

// Module 3: TAT prediction & alerts
app.get("/api/alerts", (req, res) => {
  const alerts = [];
  db.orders.forEach((o) => {
    const pred = predictRisk(o);
    if (pred) {
      alerts.push({
        order: serializeOrder(o),
        level: pred.level,
        predictedTotalHours: pred.predictedTotal,
        slaHours: pred.slaHours,
      });
    } else if (o.status !== "Delivered" && hoursLeft(o) < 0) {
      alerts.push({
        order: serializeOrder(o),
        level: "breach",
        predictedTotalHours: null,
        slaHours: LENS_SLA_HOURS[o.lensType],
      });
    }
  });
  res.json(alerts);
});

app.get("/", (req, res) => {
  res.json({ ok: true, service: "lensflow-backend", endpoints: ["/api/meta", "/api/inventory", "/api/orders", "/api/kpis", "/api/alerts", "/api/check-availability"] });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`LensFlow backend running on http://localhost:${PORT}`));
