# LensFlow — AI Order Management System

A working order-management system for an eyewear brand, split into a
**backend (Node/Express API)** and a **frontend (static HTML/CSS/JS)**.

```
lensflow/
├── backend/
│   ├── server.js        ← Express API: orders, inventory, KPIs, alerts
│   └── package.json
├── frontend/
│   ├── index.html        ← page structure (3 tabs)
│   ├── style.css         ← LensKart-style vibrant theme (pink/navy/gold/teal)
│   └── app.js            ← fetches data from the backend, renders UI
└── README.md
```

## 1. How to run it

### Step 1 — Start the backend
```bash
cd backend
npm install
npm start
```
This starts the API at **http://localhost:4000**. You'll see:
`LensFlow backend running on http://localhost:4000`

### Step 2 — Open the frontend
Just open `frontend/index.html` directly in your browser
(double-click it, or use any static file server, e.g.):
```bash
cd frontend
npx serve .
```
The frontend automatically points to `http://localhost:4000/api` when run
locally. The green "Backend connected" dot at the top-right confirms the
connection. If it's red, make sure the backend is running.

### Deploying live
- **Backend**: deploy `backend/` to any Node host (Render, Railway, Fly.io,
  Heroku). Note the URL it gives you, e.g. `https://lensflow-api.onrender.com`.
- **Frontend**: deploy `frontend/` to any static host (Netlify, Vercel,
  GitHub Pages). In `app.js`, change the `API_BASE` fallback (the `/api`
  line) to your backend's full URL, e.g.
  `const API_BASE = "https://lensflow-api.onrender.com/api";`

## 2. What changed from the single-file version

| | Before | Now |
|---|---|---|
| Structure | One HTML file with everything inline | Separate **backend** (data + logic) and **frontend** (UI only) |
| Data | Hardcoded in JS, lost on refresh | Lives on the server (`db.orders` in `server.js`), survives page refresh, shared across browser tabs |
| Look | Earthy/muted "design studio" palette | LensKart-style vibrant theme: **hot pink** (#FF3E6C) + **navy** (#14213D) + **gold** (#FFC93C) + **teal** (#00B8A9) |
| Dynamism | All client-side simulation | Real HTTP calls (`fetch`) — placing an order, changing status, or editing a delay reason actually persists on the server and is reflected for anyone else viewing the dashboard |

## 3. The three modules (how they work end-to-end)

### Module 1 — Order Intake & Inventory (`/api/inventory`, `/api/check-availability`, `POST /api/orders`)
- `frontend/index.html` has the order form.
- On submit, `app.js` calls:
  1. `POST /api/check-availability` → backend matches the prescription
     (sphere/index/coating) against `INVENTORY` in `server.js` and returns
     whether it's **In Stock**, **Low Stock**, or **Made-to-Order**, plus an
     ETA computed from `STAGE_AVG_HOURS`.
  2. `POST /api/orders` → backend creates a real order record with an
     auto-generated SLA deadline (`createdAt + LENS_SLA_HOURS[lensType]`).
- The result card and ETA are rendered with the new vibrant theme
  (teal box = in stock, gold box = lab order).

### Module 2 — Dashboard (`/api/orders`, `/api/kpis`, `PATCH /api/orders/:id`)
- `GET /api/kpis` → counts of Active / On Track / At Risk / Breached orders.
- `GET /api/orders?status=...&lensType=...&store=...&search=...` → filtered
  order list, each row including a live `hoursLeft` and `slaState`
  (`ok` / `risk` / `breach`) computed against the current time.
- Each row has a **status dropdown** and **delay-reason input**. Changing
  either sends `PATCH /api/orders/:id`, which updates the server's record.
  If you move an order from **QC → Lab Processing**, the backend
  automatically appends `"QC fail — looped back to Lab Processing"` to the
  delay reason — this is the QC-failure loop from the spec.
- The dashboard auto-refreshes every 30 seconds so SLA countdowns and
  alerts stay current even if you leave the tab open.

### Module 3 — TAT Prediction & Alerts (`/api/alerts`)
- For every active order, the backend computes:
  `predictedTotal = elapsedHours + 0.6 × (sum of average hours for all
  remaining stages for that lens type)`
  using the `STAGE_AVG_HOURS` table (the "historical data" model).
- If `predictedTotal > SLA` → **Breach Alert**.
  If `predictedTotal > 0.8 × SLA` → **At-Risk Alert**.
- The Alerts tab renders each flagged order with simulated
  **✉ Email sent** / **✆ WhatsApp sent** pills — in production these would
  be real calls to SendGrid/SES and the WhatsApp Business API, triggered by
  a scheduled job (see `architecture_note.md`).

## 4. Color palette reference (LensKart-inspired)
- `--pink: #FF3E6C` — primary action color (buttons, active tab, QC badges)
- `--navy: #14213D` — header background, headings
- `--gold: #FFC93C` — at-risk indicators, secondary accent
- `--teal: #00B8A9` — in-stock / on-track / WhatsApp indicators
- `--bg: #FAF7FB` — page background (soft lavender-white)

## 5. Extending this
- Swap `db.orders` (in-memory array in `server.js`) for a real database —
  every route already reads/writes through that one object, so the change
  is localized.
- Replace the heuristic in `predictRisk()` with a call to a trained
  ML model or an LLM-based reasoning step.
- Wire `/api/alerts` to actually call SendGrid/Twilio instead of just
  returning data for the UI to display.
